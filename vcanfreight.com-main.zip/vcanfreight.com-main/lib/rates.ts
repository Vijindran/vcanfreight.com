/**
 * SeaRates API Integration with Smart Caching (Recycle Logic)
 * 
 * This module handles fetching shipping rates from SeaRates API and implements
 * a "recycle" mechanism to stay within the 50 API calls/month limit.
 */
import type { D1Database } from '@cloudflare/workers-types';

export interface RateResult {
    price: number;
    currency: string;
    transitTime: number;
    carrier: string;
    validUntil: string;
    source: 'live' | 'cached' | 'mock';
    requiresSubscription?: boolean; // True if user needs to subscribe for real rates
    isEstimate?: boolean; // True if this is an estimated rate (not real)
}

/**
 * City name to LOCODE mapping
 * Used to resolve point IDs for SeaRates API
 */
const cityToLocode: Record<string, string> = {
    'SHANGHAI': 'CNSHA',
    'LOS ANGELES': 'USLAX',
    'NEW YORK': 'USNYC',
    'LONDON': 'GBLON',
    'DUBAI': 'AEDXB',
    'SINGAPORE': 'SGSIN',
    'HONG KONG': 'HKHKG',
    'ROTTERDAM': 'NLRTM',
    'HAMBURG': 'DEHAM',
    'ANTWERP': 'BEANT',
    'NINGBO': 'CNNGB',
    'SHENZHEN': 'CNSZX',
    'GUANGZHOU': 'CNCAN',
    'BUSAN': 'KRBUS',
    'QINGDAO': 'CNTAO',
    'PORT KELANG': 'MYPKG',
    'KAOHSIUNG': 'TWKHH',
    'LAEM CHABANG': 'THLCH',
};

/**
 * Get rates with SMART CACHING to maximize 50 API calls/month
 */
export async function getSeaRates(
    origin: string,
    destination: string,
    userId?: string
): Promise<RateResult> {
    const db = (globalThis as any).__CF_DB__ as D1Database | undefined;

    // Fallback for local development without DB
    if (!db) {
        return {
            price: 1250.00,
            currency: 'USD',
            transitTime: 24,
            carrier: 'Maersk',
            validUntil: '2025-12-31',
            source: 'mock'
        };
    }

    const now = Math.floor(Date.now() / 1000);
    const normalizedOrigin = origin.trim().toUpperCase();
    const normalizedDest = destination.trim().toUpperCase();

    // Check if user has active subscription
    let isSubscriber = false;
    if (userId && userId !== 'guest') {
        try {
            const { hasActiveSubscription } = await import('./cloudflare');
            isSubscriber = await hasActiveSubscription(db, userId);
        } catch (e) {
            console.error('Error checking subscription:', e);
        }
    }

    // STEP 1: Check cache FIRST (Recycle Logic)
    // Check both tables - any valid rate is recycled
    let cachedRate = await db.prepare(
        `SELECT * FROM life_rates 
         WHERE origin = ? AND destination = ? AND valid_until > ? 
         ORDER BY updated_at DESC LIMIT 1`
    ).bind(normalizedOrigin, normalizedDest, now).first<{
        price: number;
        currency: string;
        transit_time: number;
        carrier: string;
        valid_until: number;
    }>();

    if (!cachedRate) {
        cachedRate = await db.prepare(
            `SELECT * FROM rates_cache 
             WHERE origin = ? AND destination = ? AND valid_until > ? 
             ORDER BY created_at DESC LIMIT 1`
        ).bind(normalizedOrigin, normalizedDest, now).first<{
            price: number;
            currency: string;
            transit_time: number;
            carrier: string;
            valid_until: number;
        }>();
    }

    // If valid cache exists, recycle it! (Saves API calls)
    if (cachedRate) {
        console.log(`♻️ Recycling cached rate: ${normalizedOrigin} → ${normalizedDest}`);
        return {
            price: cachedRate.price,
            currency: cachedRate.currency || 'USD',
            transitTime: cachedRate.transit_time || 24,
            carrier: cachedRate.carrier || 'SeaRates Carrier',
            validUntil: new Date(cachedRate.valid_until * 1000).toISOString().split('T')[0],
            source: isSubscriber ? 'live' : 'cached',
            requiresSubscription: !isSubscriber,
            isEstimate: !isSubscriber
        };
    }

    // STEP 2: No cache found - only subscribers can trigger API calls
    if (!isSubscriber) {
        return {
            price: 1250.00,
            currency: 'USD',
            transitTime: 24,
            carrier: 'Maersk (Estimated)',
            validUntil: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            source: 'mock',
            requiresSubscription: true,
            isEstimate: true
        };
    }

    // STEP 3: Subscriber triggers fresh API call
    const realTimeRate = await fetchRealTimeRate(normalizedOrigin, normalizedDest);

    if (realTimeRate) {
        const validUntil = Math.floor(Date.now() / 1000) + (7 * 24 * 60 * 60); // 7 days
        const timestamp = Math.floor(Date.now() / 1000);

        // Store in BOTH tables for future recycling
        try {
            const lifeRateId = `life_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            await db.prepare(
                `INSERT INTO life_rates (id, origin, destination, price, currency, transit_time, carrier, valid_until, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
            ).bind(lifeRateId, normalizedOrigin, normalizedDest, realTimeRate.price, realTimeRate.currency,
                realTimeRate.transitTime, realTimeRate.carrier, validUntil, timestamp, timestamp).run();

            const cacheRateId = `cache_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            await db.prepare(
                `INSERT INTO rates_cache (id, origin, destination, price, currency, transit_time, carrier, valid_until, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
            ).bind(cacheRateId, normalizedOrigin, normalizedDest, realTimeRate.price, realTimeRate.currency,
                realTimeRate.transitTime, realTimeRate.carrier, validUntil, timestamp).run();

            console.log(`✅ Fresh rate cached for future recycling: ${normalizedOrigin} → ${normalizedDest}`);
        } catch (e) {
            console.error('Error storing rate in cache:', e);
        }

        return {
            ...realTimeRate,
            validUntil: new Date(validUntil * 1000).toISOString().split('T')[0],
            source: 'live'
        };
    }

    // API failed, return mock
    return {
        price: 1250.00,
        currency: 'USD',
        transitTime: 24,
        carrier: 'Maersk (Estimated)',
        validUntil: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        source: 'mock',
        requiresSubscription: true,
        isEstimate: true
    };
}

/**
 * Fetch real-time rate from SeaRates API
 */
async function fetchRealTimeRate(origin: string, destination: string): Promise<RateResult | null> {
    const platformId = process.env.SEARATES_PLATFORM_ID || '29979';
    const apiKey = process.env.SEARATES_API_KEY || 'K-21EB16AA-B6A6-4D41-9365-5882597F9B11';

    console.log(`📡 Fetching live SeaRates API for: ${origin} → ${destination}`);

    // 1. Get Token (Proven working URL)
    let token = null;
    try {
        const tokenRes = await fetch(`https://www.searates.com/auth/platform-token?id=${platformId}&api_key=${apiKey}`);
        if (tokenRes.ok) {
            const data = await tokenRes.json() as any;
            token = data['s-token'] || data.token || data.access_token;
        }
    } catch (e) {
        console.error('SeaRates Auth Failed:', e instanceof Error ? e.message : String(e));
        return null;
    }

    if (!token) return null;

    // 2. Try GraphQL with correct point format
    // P_ followed by LOCODE is the best guess for working IDs
    const fromId = cityToLocode[origin] ? `P_${cityToLocode[origin]}` : origin;
    const toId = cityToLocode[destination] ? `P_${cityToLocode[destination]}` : destination;

    try {
        const response = await fetch('https://rates.searates.com/graphql', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                query: `
                    query {
                        rates(
                            pointIdFrom: "${fromId}",
                            pointIdTo: "${toId}",
                            shippingType: FCL,
                            container: ST20
                        ) {
                            __typename
                            # Using FclRate fields if possible, or generic
                            ... on FclRate {
                                total_price
                                total_cost
                                amount
                                currency
                                transit_time
                                carrier { name }
                            }
                        }
                    }
                `
            })
        });

        const data = await response.json() as any;
        const rate = data.data?.rates?.[0] || data.data?.rates;

        if (rate) {
            console.log('✅ SeaRates API success!');
            return {
                price: rate.total_price || rate.total_cost || rate.amount || 1250.00,
                currency: rate.currency || 'USD',
                transitTime: rate.transit_time || 24,
                carrier: rate.carrier?.name || 'SeaRates Carrier',
                validUntil: '', // Will be set by caller
                source: 'live'
            };
        }
    } catch (e) {
        console.error('SeaRates API call failed:', e instanceof Error ? e.message : String(e));
    }

    return null;
}
