'use client';

import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { useRouter } from 'next/navigation';

type User = {
    id: string;
    name: string;
    email: string;
};

type AuthContextType = {
    user: User | null;
    isGuest: boolean;
    login: (email: string, password: string) => Promise<void>;
    loginWithGoogle: () => Promise<void>;
    register: (name: string, email: string, password: string) => Promise<void>;
    loginAsGuest: () => void;
    logout: () => void;
    isLoading: boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Helper to get API base URL
function getApiUrl() {
    if (typeof window !== 'undefined') {
        return window.location.origin;
    }
    return process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';
}

// Helper to get token from localStorage
function getToken(): string | null {
    if (typeof window !== 'undefined') {
        return localStorage.getItem('auth_token');
    }
    return null;
}

// Helper to set token in localStorage
function setToken(token: string) {
    if (typeof window !== 'undefined') {
        localStorage.setItem('auth_token', token);
    }
}

// Helper to remove token from localStorage
function removeToken() {
    if (typeof window !== 'undefined') {
        localStorage.removeItem('auth_token');
    }
}

// Helper to set guest mode
function setGuestMode(isGuest: boolean) {
    if (typeof window !== 'undefined') {
        if (isGuest) {
            localStorage.setItem('is_guest', 'true');
        } else {
            localStorage.removeItem('is_guest');
        }
    }
}

// Helper to get guest mode
function getGuestMode(): boolean {
    if (typeof window !== 'undefined') {
        return localStorage.getItem('is_guest') === 'true';
    }
    return false;
}

export function AuthProvider({ children }: { children: ReactNode }) {
    const [user, setUser] = useState<User | null>(null);
    const [isGuest, setIsGuest] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const router = useRouter();
    const authChecked = React.useRef(false);
    const mountCount = React.useRef(0);

    // Check for existing auth on mount
    useEffect(() => {
        mountCount.current++;
        const token = getToken();
        
        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'context/AuthContext.tsx:83',message:'Auth check effect running',data:{timestamp:Date.now(),hasToken:!!token,isGuest:getGuestMode(),mountCount:mountCount.current,authChecked:authChecked.current},timestamp:Date.now(),sessionId:'debug-session',runId:'auth-loop-check',hypothesisId:'LOOP'})}).catch(()=>{});
        // #endregion
        
        if (authChecked.current) {
            return;
        }
        authChecked.current = true;
        
        // Check for token in URL (from OAuth callback)
        if (typeof window !== 'undefined') {
            const urlParams = new URLSearchParams(window.location.search);
            const urlToken = urlParams.get('token');
            if (urlToken) {
                setToken(urlToken);
                // Remove token from URL
                window.history.replaceState({}, '', window.location.pathname);
            }
        }

        // Check for guest mode
        const guestMode = getGuestMode();
        if (guestMode) {
            setIsGuest(true);
            setUser({
                id: 'guest',
                name: 'Guest User',
                email: '',
            });
            setIsLoading(false);
            return;
        }

        const token = getToken();
        if (token) {
            // Verify token and get user info
            fetch(`${getApiUrl()}/api/auth/me`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            })
                .then(async (res) => {
                    // #region agent log
                    fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'context/AuthContext.tsx:112',message:'Auth API response received',data:{status:res.status,ok:res.ok},timestamp:Date.now(),sessionId:'debug-session',runId:'auth-loop-check',hypothesisId:'LOOP'})}).catch(()=>{});
                    // #endregion
                    
                    if (!res.ok) {
                        // #region agent log
                        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'context/AuthContext.tsx:112',message:'Auth check failed',data:{status:res.status,statusText:res.statusText},timestamp:Date.now(),sessionId:'debug-session',runId:'auth-fail-debug',hypothesisId:'401'})}).catch(()=>{});
                        // #endregion
                        throw new Error(`Auth failed with status: ${res.status}`);
                    }
                    return res.json();
                })
                .then(data => {
                    if (data.user) {
                        setUser(data.user);
                        setIsGuest(false);
                    } else {
                        removeToken();
                    }
                })
                .catch((err) => {
                    console.warn('Session expired or invalid:', err.message);
                    removeToken();
                })
                .finally(() => {
                    setIsLoading(false);
                });
        } else {
            setIsLoading(false);
        }
    }, []);

    const login = async (email: string, password: string) => {
        setIsLoading(true);
        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'context/AuthContext.tsx:168',message:'Login initiated',data:{email},timestamp:Date.now(),sessionId:'debug-session',runId:'auth-debug',hypothesisId:'AUTH'})}).catch(()=>{});
        // #endregion
        try {
            const response = await fetch(`${getApiUrl()}/api/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }),
            });

            const data = await response.json();
            // #region agent log
            fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'context/AuthContext.tsx:181',message:'Login response',data:{ok:response.ok,status:response.status,hasUser:!!data.user,hasToken:!!data.token},timestamp:Date.now(),sessionId:'debug-session',runId:'auth-debug',hypothesisId:'AUTH'})}).catch(()=>{});
            // #endregion

            if (!response.ok) {
                throw new Error(data.error || 'Login failed');
            }

            setToken(data.token);
            setUser(data.user);
            setIsGuest(false);
            setGuestMode(false);
            router.push('/booking');
        } catch (error: any) {
            console.error("Login Failed:", error);
            alert("Login Failed. " + (error.message || 'Please check your credentials.'));
        } finally {
            setIsLoading(false);
        }
    };

    const loginWithGoogle = async () => {
        setIsLoading(true);
        try {
            // #region agent log
            fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'context/AuthContext.tsx:203',message:'Google login initiated',data:{timestamp:Date.now()},timestamp:Date.now(),sessionId:'debug-session',runId:'auth-debug',hypothesisId:'GOOGLE'})}).catch(()=>{});
            // #endregion
            
            // Redirect to Google OAuth
            const response = await fetch(`${getApiUrl()}/api/auth/google`, {
                method: 'GET',
            });

            if (!response.ok) {
                const data = await response.json().catch(() => ({}));
                // #region agent log
                fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'context/AuthContext.tsx:212',message:'Google login error response',data:{status:response.status,code:data.code},timestamp:Date.now(),sessionId:'debug-session',runId:'auth-debug',hypothesisId:'GOOGLE'})}).catch(()=>{});
                // #endregion
                
                if (response.status === 503 || data.code === 'OAUTH_NOT_CONFIGURED') {
                    alert("Google Sign-In is not configured. Please use email/password login or continue as guest.");
                    return;
                }
                throw new Error(data.error || `Google Sign-In failed with status: ${response.status}`);
            }

            if (response.redirected) {
                window.location.href = response.url;
            } else {
                const data = await response.json();
                if (data.url) {
                    window.location.href = data.url;
                } else {
                    throw new Error(data.error || 'Google Sign-In unavailable');
                }
            }
        } catch (error: any) {
            console.error("Google Login Failed:", error);
            // #region agent log
            fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'context/AuthContext.tsx:235',message:'Google login exception',data:{error:error.message},timestamp:Date.now(),sessionId:'debug-session',runId:'auth-debug',hypothesisId:'GOOGLE'})}).catch(()=>{});
            // #endregion
            alert("Google Sign-In is currently unavailable. " + (error.message || 'Please use another method.'));
        } finally {
            setIsLoading(false);
        }
    };

    const register = async (name: string, email: string, password: string) => {
        setIsLoading(true);
        try {
            const response = await fetch(`${getApiUrl()}/api/auth/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ name, email, password }),
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Registration failed');
            }

            setToken(data.token);
            setUser(data.user);
            setIsGuest(false);
            setGuestMode(false);
            router.push('/booking');
        } catch (error: any) {
            console.error("Registration Failed:", error);
            alert("Registration Failed. " + (error.message || 'Please try again.'));
        } finally {
            setIsLoading(false);
        }
    };

    const loginAsGuest = () => {
        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'context/AuthContext.tsx:260',message:'Login as guest',data:{timestamp:Date.now()},timestamp:Date.now(),sessionId:'debug-session',runId:'auth-debug',hypothesisId:'GUEST'})}).catch(()=>{});
        // #endregion
        setGuestMode(true);
        setIsGuest(true);
        setUser({
            id: 'guest',
            name: 'Guest User',
            email: '',
        });
        router.push('/booking');
    };

    const logout = async () => {
        try {
            removeToken();
            setGuestMode(false);
            setUser(null);
            setIsGuest(false);
            router.push('/auth/login');
        } catch (error) {
            console.error("Logout Failed:", error);
        }
    };

    return (
        <AuthContext.Provider value={{ user, isGuest, login, loginWithGoogle, register, loginAsGuest, logout, isLoading }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
