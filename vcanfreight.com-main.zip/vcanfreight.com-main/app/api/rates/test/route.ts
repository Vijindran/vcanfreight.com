import { NextResponse } from 'next/server';
import { getSeaRates } from '@/lib/rates';

export const dynamic = 'force-dynamic';
export const runtime = 'edge';

/**
 * Test endpoint for SeaRates API
 * GET /api/rates/test?origin=Shanghai&destination=Los Angeles&userId=test
 */
export async function GET(request: Request) {
    try {
        const { searchParams } = new URL(request.url);
        const origin = searchParams.get('origin') || 'Shanghai';
        const destination = searchParams.get('destination') || 'Los Angeles';
        const userId = searchParams.get('userId') || undefined;

        console.log('🧪 Testing rates API...');
        console.log(`   Origin: ${origin}`);
        console.log(`   Destination: ${destination}`);
        console.log(`   User ID: ${userId || 'none (non-subscriber)'}`);

        // Test the rates function
        const rate = await getSeaRates(origin, destination, userId);

        const result = {
            success: true,
            test: {
                origin,
                destination,
                userId: userId || null,
                timestamp: new Date().toISOString(),
            },
            rate,
            apiStatus: {
                platformId: process.env.SEARATES_PLATFORM_ID || '29979',
                apiKeyConfigured: !!process.env.SEARATES_API_KEY || true, // Default key in code
                apiUrl: process.env.SEARATES_API_URL || 'https://api.searates.com/v2',
            },
            cacheStatus: rate.source === 'life' ? 'From life_rates cache' : 
                        rate.source === 'cached' ? 'From rates_cache' : 
                        rate.source === 'mock' ? 'Mock data (no cache, no API call)' : 'Unknown',
        };

        console.log('✅ Test result:', JSON.stringify(result, null, 2));

        return NextResponse.json(result, {
            headers: {
                'Content-Type': 'application/json',
            },
        });
    } catch (error: any) {
        console.error('❌ Test error:', error);
        return NextResponse.json(
            {
                success: false,
                error: error.message,
                stack: process.env.NODE_ENV === 'development' ? error.stack : undefined,
            },
            { status: 500 }
        );
    }
}

