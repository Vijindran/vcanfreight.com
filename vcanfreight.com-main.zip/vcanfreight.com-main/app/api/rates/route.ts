import { NextResponse } from 'next/server';
import { getSeaRates } from '@/lib/rates';

export const dynamic = 'force-dynamic';
export const runtime = 'edge';

export async function GET(request: Request) {
    const { searchParams } = new URL(request.url);
    const origin = searchParams.get('origin');
    const destination = searchParams.get('destination');
    const type = searchParams.get('type') || 'FCL'; // 'FCL', 'LCL', 'AIR'

    if (!origin || !destination) {
        return NextResponse.json({ error: 'Origin and destination required' }, { status: 400 });
    }

    try {
        // Get user ID from auth token if available
        let userId: string | undefined;
        const authHeader = request.headers.get('Authorization');
        if (authHeader && authHeader.startsWith('Bearer ')) {
            try {
                const token = authHeader.substring(7);
                const jwtSecret = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
                const { verifyJWT } = await import('@/lib/cloudflare');
                const user = await verifyJWT(token, jwtSecret);
                if (user) {
                    userId = user.userId;
                }
            } catch (e) {
                // Invalid token - treat as guest
            }
        }

        const rate = await getSeaRates(origin, destination, userId);

        return NextResponse.json({
            rates: [
                {
                    id: `rate_${Date.now()}`,
                    carrier: rate.carrier,
                    price: rate.price,
                    currency: rate.currency,
                    transitTime: rate.transitTime,
                    cutoff: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Mock cutoff
                    serviceType: type,
                    requiresSubscription: (rate as any).requiresSubscription,
                    isEstimate: (rate as any).isEstimate
                }
            ]
        });
    } catch (error: any) {
        console.error('Rate fetch error:', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
