import { NextResponse } from 'next/server';
import { getUserByEmail, createUser, generateJWT } from '@/lib/cloudflare';
import type { D1Database } from '@cloudflare/workers-types';

export const dynamic = 'force-dynamic';
export const runtime = 'edge';

export async function GET(request: Request) {
    try {
        const url = new URL(request.url);
        const code = url.searchParams.get('code');

        if (!code) {
            return NextResponse.redirect(new URL('/auth/login?error=oauth_failed', request.url));
        }

        const clientId = process.env.GOOGLE_CLIENT_ID;
        const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
        const redirectUri = `${new URL(request.url).origin}/api/auth/google/callback`;

        if (!clientId || !clientSecret) {
            return NextResponse.redirect(new URL('/auth/login?error=oauth_not_configured', request.url));
        }

        // Exchange code for access token
        const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                code,
                client_id: clientId,
                client_secret: clientSecret,
                redirect_uri: redirectUri,
                grant_type: 'authorization_code',
            }),
        });

        const tokenData = await tokenResponse.json();

        if (!tokenData.access_token) {
            return NextResponse.redirect(new URL('/auth/login?error=token_exchange_failed', request.url));
        }

        // Get user info from Google
        const userResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
            headers: {
                Authorization: `Bearer ${tokenData.access_token}`,
            },
        });

        const googleUser = await userResponse.json();

        const db = (globalThis as any).__CF_DB__ as D1Database | undefined;
        const jwtSecret = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

        if (!db) {
            // Fallback for local development
            return NextResponse.redirect(new URL('/booking?token=mock_token', request.url));
        }

        // Check if user exists
        let user = await getUserByEmail(db, googleUser.email);

        if (!user) {
            // Create new user
            const userId = await createUser(db, googleUser.email, googleUser.name, '');
            // Update with Google ID
            await db.prepare(
                'UPDATE users SET google_id = ? WHERE id = ?'
            ).bind(googleUser.id, userId).run();
            user = await getUserByEmail(db, googleUser.email);
        } else if (!user.google_id) {
            // Link Google account
            await db.prepare(
                'UPDATE users SET google_id = ? WHERE id = ?'
            ).bind(googleUser.id, user.id).run();
        }

        // Generate JWT token
        const token = await generateJWT(user!.id, user!.email, jwtSecret);

        // Redirect to booking page with token in URL (client will store it in localStorage)
        const bookingUrl = new URL('/booking', request.url);
        bookingUrl.searchParams.set('token', token);
        
        return NextResponse.redirect(bookingUrl);
    } catch (error: any) {
        console.error('Google OAuth callback error:', error);
        return NextResponse.redirect(new URL('/auth/login?error=oauth_error', request.url));
    }
}

