import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const runtime = 'edge';

// Google OAuth handler
// This will redirect to Google OAuth and handle the callback
export async function GET(request: Request) {
    try {
        const clientId = process.env.GOOGLE_CLIENT_ID;
        const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${new URL(request.url).origin}/api/auth/google/callback`;
        
        if (!clientId) {
            // Return a user-friendly error instead of 500
            return NextResponse.json(
                { 
                    error: 'Google Sign-In is not available at the moment. Please use email/password login or continue as guest.',
                    code: 'OAUTH_NOT_CONFIGURED'
                },
                { status: 503 }
            );
        }

        const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
        authUrl.searchParams.set('client_id', clientId);
        authUrl.searchParams.set('redirect_uri', redirectUri);
        authUrl.searchParams.set('response_type', 'code');
        authUrl.searchParams.set('scope', 'openid email profile');
        authUrl.searchParams.set('access_type', 'offline');
        authUrl.searchParams.set('prompt', 'consent');

        return NextResponse.redirect(authUrl.toString());
    } catch (error: any) {
        console.error('Google OAuth error:', error);
        return NextResponse.json(
            { error: 'Google Sign-In is temporarily unavailable. Please try another method.' },
            { status: 503 }
        );
    }
}

