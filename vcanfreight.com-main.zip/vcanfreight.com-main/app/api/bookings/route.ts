import { getRequestContext } from '@cloudflare/next-on-pages';
import { NextResponse } from 'next/server';
import { verifyJWT } from '@/lib/cloudflare';
import type { D1Database } from '@cloudflare/workers-types';
import { createSearatesBooking, type SearatesBookingRequest } from '@/lib/bookings';

export const dynamic = 'force-dynamic';
export const runtime = 'edge';

// Helper to get user from JWT token
async function getUserFromRequest(request: Request): Promise<{ userId: string; email: string } | null> {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return null;
    }

    const token = authHeader.substring(7);
    const jwtSecret = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
    return await verifyJWT(token, jwtSecret);
}

export async function POST(request: Request) {
    // #region agent log
    fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'bookings/route.ts:21',message:'POST booking endpoint called',data:{timestamp:Date.now()},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'A'})}).catch(()=>{});
    // #endregion
    try {
        let user = await getUserFromRequest(request);
        
        // If no user, treat as guest booking
        if (!user) {
            const guestId = 'guest_' + Date.now();
            console.log('👤 [Booking] No authenticated user, treating as guest booking:', guestId);
            // #region agent log
            fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'app/api/bookings/route.ts:33',message:'Guest user generated',data:{guestId},timestamp:Date.now(),sessionId:'debug-session',runId:'booking-flow',hypothesisId:'GUEST'})}).catch(()=>{});
            // #endregion
            user = {
                userId: guestId,
                email: 'guest@vcanfreight.com'
            };
        }

        const bookingData = await request.json() as any;
        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'bookings/route.ts:32',message:'Booking data received',data:{bookingType:bookingData.bookingType,hasSelectedQuote:!!bookingData.selectedQuote,origin:bookingData.origin||bookingData.airOrigin,destination:bookingData.destination||bookingData.airDest},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        // Get DB using next-on-pages context
        let db: D1Database | undefined = (globalThis as any).__CF_DB__;
        try {
            const ctx = getRequestContext();
            if (ctx.env && (ctx.env as any).DB) {
                db = (ctx.env as any).DB as D1Database;
            }
        } catch (e) { /* ignore */ }

        if (!db) {
            // #region agent log
            fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'bookings/route.ts:57',message:'No DB - cannot proceed without Searates booking',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'C'})}).catch(()=>{});
            // #endregion
            // In production, DB is required for booking creation
            return NextResponse.json({
                error: 'Database not available',
                message: 'Booking system is not available. Please contact support.'
            }, { status: 503 });
        }

        // Create booking in D1 database
        const now = Math.floor(Date.now() / 1000);

        // Determine values based on type
        const type = bookingData.bookingType || 'FCL';
        const origin = type === 'AIR' ? bookingData.airOrigin : bookingData.origin;
        const destination = type === 'AIR' ? bookingData.airDest : bookingData.destination;
        const cargo = type === 'AIR'
            ? `${bookingData.pieces} pieces, ${bookingData.weight}kg`
            : bookingData.commodity || 'General Cargo';

        // For FCL, container type summary
        const containerType = type === 'FCL'
            ? Object.entries(bookingData.equipment || {}).map(([k, v]) => `${v}x ${k}`).join(', ')
            : type;

        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'bookings/route.ts:70',message:'Preparing Searates booking request',data:{type,origin,destination,hasSelectedQuote:!!bookingData.selectedQuote},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        // CRITICAL: Create actual booking via Searates API BEFORE saving locally
        // Extract container type and count for FCL bookings
        let containerTypeForSearates: string | undefined;
        let containerCount: number | undefined;
        if (type === 'FCL' && bookingData.equipment) {
            // Get first non-zero container type (simplified - may need to handle multiple types)
            const entries = Object.entries(bookingData.equipment).filter(([, count]) => count > 0);
            if (entries.length > 0) {
                containerTypeForSearates = entries[0][0]; // e.g., "40' Standard"
                containerCount = entries[0][1] as number;
            }
        }

        // Extract shipment_id from selected quote
        // ⚠️ CRITICAL: shipment_id format is string like "SRT-2024-00345-88A" (not integer)
        // shipmentId comes from Searates API response when rate was fetched
        const shipmentId = bookingData.selectedQuote?.shipmentId || 
                          bookingData.selectedQuote?.id || // Fallback to id if shipmentId not set
                          undefined;
        
        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'app/api/bookings/route.ts:98',message:'Extracting shipmentId from quote',data:{hasSelectedQuote:!!bookingData.selectedQuote,shipmentId:shipmentId||'none',quoteId:bookingData.selectedQuote?.id||'none',selectedQuoteKeys:bookingData.selectedQuote?Object.keys(bookingData.selectedQuote):[]},timestamp:Date.now(),sessionId:'debug-session',runId:'booking-flow',hypothesisId:'BOOKING'})}).catch(()=>{});
        // #endregion

        // Log full quote data for debugging
        console.log('📋 [Booking] Selected quote data:', JSON.stringify(bookingData.selectedQuote, null, 2));
        
        // Check if shipmentId is valid (not temporary/generated)
        const isTempOrGenerated = shipmentId?.startsWith('TEMP-') || shipmentId?.startsWith('rate_');
        const finalShipmentId = (shipmentId && !isTempOrGenerated && shipmentId.trim() !== '') ? shipmentId : undefined;
        
        if (!finalShipmentId) {
            console.warn('⚠️ [Booking] shipmentId missing or invalid - proceeding without it. Searates API will accept or reject based on their requirements.');
        }

        // Get port codes helper
        const { getPortCode, getCountryCode, getDefaultPortAddress } = await import('@/lib/port-codes');
        
        // Build route information with port codes
        const originCity = origin || 'Unknown';
        const destCity = destination || 'Unknown';
        const originPortCode = getPortCode(originCity) || '';
        const destPortCode = getPortCode(destCity) || '';
        const originCountry = bookingData.route?.origin?.country || getCountryCode(originCity) || '';
        const destCountry = bookingData.route?.destination?.country || getCountryCode(destCity) || '';

        // Extract container type and quantity for equipment
        let containerType = '';
        let containerQuantity = 0;
        if (type === 'FCL' && bookingData.equipment) {
            const entries = Object.entries(bookingData.equipment).filter(([, count]) => (count as number) > 0);
            if (entries.length > 0) {
                containerType = entries[0][0]; // e.g., "40' Standard" - need to normalize to "40HC", "40ft", "20ft"
                containerQuantity = entries[0][1] as number;
                
                // Normalize container type names to Searates format
                if (containerType.includes("40' High Cube") || containerType.includes("40HC")) {
                    containerType = '40HC';
                } else if (containerType.includes("40' Standard") || containerType.includes("40ft")) {
                    containerType = '40ft';
                } else if (containerType.includes("20' Standard") || containerType.includes("20ft")) {
                    containerType = '20ft';
                }
            }
        }

        // Build Searates booking request matching ACTUAL API structure
        const searatesBookingRequest: SearatesBookingRequest = {
            ...(finalShipmentId ? { shipmentId: finalShipmentId } : {}), // Only include if valid
            rateId: bookingData.selectedQuote?.id, // Pass rate ID as fallback option
            platformId: parseInt(process.env.SEARATES_PLATFORM_ID || '29979', 10),
            route: {
                origin: {
                    port_code: bookingData.route?.origin?.port_code || originPortCode,
                    city: bookingData.route?.origin?.city || originCity.split(',')[0].trim(),
                    country: originCountry,
                    address: bookingData.route?.origin?.address || getDefaultPortAddress(originPortCode, originCity)
                },
                destination: {
                    port_code: bookingData.route?.destination?.port_code || destPortCode,
                    city: bookingData.route?.destination?.city || destCity.split(',')[0].trim(),
                    country: destCountry,
                    address: bookingData.route?.destination?.address || getDefaultPortAddress(destPortCode, destCity)
                }
            },
            equipment: {
                type: containerType || type,
                quantity: containerQuantity || 1,
                cargo_weight_kg: bookingData.weightUnit === 'MT' ? (bookingData.weight || 0) * 1000 : (bookingData.weight || 0), // Convert MT to KG
                cargo_description: bookingData.commodity || 'General Cargo',
                hs_code: bookingData.hsCode
            },
            parties: {
                shipper: {
                    // ✅ Use user info as shipper (reasonable default for B2C)
                    company: bookingData.shipperInfo?.company || `${user.email.split('@')[0]} Shipping Company`,
                    contact: bookingData.shipperInfo?.contact || user.email.split('@')[0],
                    email: bookingData.shipperInfo?.email || user.email,
                    phone: bookingData.shipperInfo?.phone || bookingData.shipperInfo?.phoneNumber || '+1234567890',
                    address: bookingData.shipperInfo?.address || bookingData.route?.origin?.address || getDefaultPortAddress(originPortCode, originCity),
                    tax_id: bookingData.shipperInfo?.tax_id || bookingData.shipperInfo?.taxId
                },
                consignee: {
                    // ✅ Use consignee info if provided, otherwise use user info (for B2C where user may be both)
                    company: bookingData.consigneeInfo?.company || bookingData.consigneeInfo?.companyName || `${user.email.split('@')[0]} Receiving Company`,
                    contact: bookingData.consigneeInfo?.contact || 
                            (bookingData.consigneeInfo?.firstName && bookingData.consigneeInfo?.lastName ? 
                                `${bookingData.consigneeInfo.firstName} ${bookingData.consigneeInfo.lastName}` : 
                                user.email.split('@')[0]),
                    email: bookingData.consigneeInfo?.email || bookingData.consigneeInfo?.emailAddress || user.email,
                    phone: bookingData.consigneeInfo?.phone || bookingData.consigneeInfo?.phoneNumber || '+1234567890',
                    address: bookingData.consigneeInfo?.address || bookingData.route?.destination?.address || getDefaultPortAddress(destPortCode, destCity),
                    tax_id: bookingData.consigneeInfo?.tax_id || bookingData.consigneeInfo?.taxId
                }
            },
            dates: {
                cargo_ready: bookingData.date || new Date().toISOString().split('T')[0],
                estimated_departure: bookingData.dates?.estimated_departure,
                estimated_arrival: bookingData.dates?.estimated_arrival
            },
            payment_terms: bookingData.payment_terms || 'Prepaid',
            references: {
                client_reference: bookingData.references?.client_reference,
                internal_reference: bookingData.references?.internal_reference || `VCAN-${Date.now()}`
            }
        };

        // Log booking request details before API call
        console.log(`📋 [Booking] Creating Searates booking:`, {
            shipmentId,
            type,
            origin: `${originCity} (${originPortCode})`,
            destination: `${destCity} (${destPortCode})`,
            containerType: containerType || type,
            shipperCompany: searatesBookingRequest.parties.shipper.company,
            consigneeCompany: searatesBookingRequest.parties.consignee.company
        });
        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'app/api/bookings/route.ts:207',message:'Calling Searates booking API',data:{shipmentId,type,origin:originCity,dest:destCity,hasCredentials:!!process.env.SEARATES_LOGIN},timestamp:Date.now(),sessionId:'debug-session',runId:'booking-flow',hypothesisId:'BOOKING'})}).catch(()=>{});
        // #endregion

        // Attempt Searates booking
        const searatesBooking = await createSearatesBooking(searatesBookingRequest, user.userId, db);

        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'app/api/bookings/route.ts:244',message:'Searates booking attempt result',data:{success:searatesBooking.success,hasBookingId:!!searatesBooking.bookingId,status:searatesBooking.status,error:searatesBooking.error,message:searatesBooking.message,details:searatesBooking.details},timestamp:Date.now(),sessionId:'debug-session',runId:'booking-flow',hypothesisId:'BOOKING'})}).catch(()=>{});
        // #endregion

        // FAILSAFE: If Searates booking fails, DO NOT proceed with local booking
        // This prevents accepting payments for fake bookings
        if (!searatesBooking.success || !searatesBooking.bookingId) {
            // Check if it's a shipment_id error specifically
            const isShipmentIdError = searatesBooking.details?.isShipmentIdError || 
                                     searatesBooking.message?.toLowerCase().includes('shipment') ||
                                     searatesBooking.error?.toLowerCase().includes('shipment');
            // #region agent log
            fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'bookings/route.ts:135',message:'Searates booking failed - REJECTING booking request',data:{success:searatesBooking.success,hasBookingId:!!searatesBooking.bookingId,error:searatesBooking.error,message:searatesBooking.message,details:(searatesBooking as any).details},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'D'})}).catch(()=>{});
            // #endregion
            console.error('Searates booking failed:', {
                success: searatesBooking.success,
                bookingId: searatesBooking.bookingId,
                error: searatesBooking.error,
                message: searatesBooking.message,
                details: searatesBooking.details,
                isShipmentIdError
            });
            
            // Provide user-friendly error message
            let userMessage = searatesBooking.message || searatesBooking.error || 'Unable to confirm booking with shipping carrier. Please try again or contact support.';
            
            if (isShipmentIdError) {
                userMessage = 'Unable to create booking: The selected shipping rate is missing required information. This is a technical issue - please contact support with your quote details (Quote ID: ' + (bookingData.selectedQuote?.id || 'unknown') + '), or try selecting a different shipping quote.';
            }
            
            return NextResponse.json(
                {
                    error: 'Failed to create booking with carrier',
                    message: userMessage,
                    details: {
                        ...(searatesBooking.details || {}),
                        troubleshooting: isShipmentIdError ? {
                            issue: 'Missing shipment_id from rate',
                            action: 'The Searates rates API may not return shipment_id. Contact Searates support or check API documentation for the correct booking flow.',
                            alternative: 'Try selecting a different shipping quote, or contact support with quote ID: ' + (bookingData.selectedQuote?.id || 'unknown')
                        } : undefined
                    },
                    debug: process.env.NODE_ENV === 'development' ? {
                        searatesError: searatesBooking.error,
                        searatesMessage: searatesBooking.message,
                        fullResponse: searatesBooking,
                        isShipmentIdError
                    } : undefined
                },
                { status: 400 }
            );
        }

        // Use Searates booking ID as the primary booking identifier
        const finalBookingId = searatesBooking.bookingId;

        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'bookings/route.ts:123',message:'Searates booking successful - proceeding with local DB save',data:{searatesBookingId:finalBookingId,carrierBookingNumber:searatesBooking.carrierBookingNumber},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        // Store both Searates booking ID and carrier booking number in local DB
        // Try to insert with carrier_booking_number if column exists, otherwise without it
        try {
            await db.prepare(
                `INSERT INTO bookings (id, user_id, container_type, origin, destination, cargo_description, booking_status, carrier_booking_number, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
            ).bind(
                finalBookingId, // Use Searates booking ID instead of local generated ID
                user.userId,
                containerType,
                origin || 'Unknown',
                destination || 'Unknown',
                cargo,
                searatesBooking.status || 'confirmed', // Use status from Searates
                searatesBooking.carrierBookingNumber || null,
                now,
                now
            ).run();
        } catch (e: any) {
            // Fallback: If carrier_booking_number column doesn't exist, insert without it
            if (e?.message?.includes('no such column: carrier_booking_number')) {
                await db.prepare(
                    `INSERT INTO bookings (id, user_id, container_type, origin, destination, cargo_description, booking_status, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
                ).bind(
                    finalBookingId,
                    user.userId,
                    containerType,
                    origin || 'Unknown',
                    destination || 'Unknown',
                    cargo,
                    searatesBooking.status || 'confirmed',
                    now,
                    now
                ).run();
            } else {
                throw e; // Re-throw if it's a different error
            }
        }
        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'bookings/route.ts:172',message:'Booking saved to local DB with Searates booking ID',data:{finalBookingId,searatesBookingId:finalBookingId,carrierBookingNumber:searatesBooking.carrierBookingNumber},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'A'})}).catch(()=>{});
        // #endregion

        // Send email notifications
        try {
            const { sendOwnerBookingNotification, sendCustomerBookingConfirmation } = await import('@/lib/email');

            // Prepare email data
            const emailData = {
                bookingId: finalBookingId,
                bookingNumber: searatesBooking.carrierBookingNumber || finalBookingId, // Prefer carrier booking number
                customerName: user.email.split('@')[0], // Use email prefix as name fallback
                customerEmail: user.email,
                origin: origin || 'Unknown',
                destination: destination || 'Unknown',
                bookingType: type,
                carrier: bookingData.selectedQuote?.carrier,
                price: bookingData.selectedQuote?.price,
                currency: bookingData.selectedQuote?.currency,
                equipment: containerType,
                commodity: bookingData.commodity,
                weight: bookingData.weight,
                readyDate: bookingData.date
            };

            // Send owner notification (critical - don't fail booking if this fails)
            sendOwnerBookingNotification(emailData).catch(err => {
                console.error('Failed to send owner notification:', err);
            });

            // Send customer confirmation (critical - don't fail booking if this fails)
            sendCustomerBookingConfirmation(emailData).catch(err => {
                console.error('Failed to send customer confirmation:', err);
            });
        } catch (emailError) {
            console.error('Email notification error:', emailError);
            // Don't fail the booking if email fails
        }

        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/1de1d5bc-6d62-400b-9e6a-817774ba82de',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'bookings/route.ts:162',message:'Returning booking response with Searates booking ID',data:{bookingId:finalBookingId,hasCarrierReference:!!searatesBooking.carrierBookingNumber,searatesBookingId:finalBookingId,carrierBookingNumber:searatesBooking.carrierBookingNumber},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'A'})}).catch(()=>{});
        // #endregion
        return NextResponse.json({
            success: true,
            bookingId: finalBookingId,
            searatesBookingId: finalBookingId, // Include for clarity
            carrierBookingNumber: searatesBooking.carrierBookingNumber,
            status: searatesBooking.status || 'confirmed',
            message: searatesBooking.message || 'Booking created successfully with carrier'
        });
    } catch (error: any) {
        console.error('Booking creation error:', error);
        return NextResponse.json(
            { error: 'Failed to create booking', message: error.message },
            { status: 500 }
        );
    }
}

export async function GET(request: Request) {
    try {
        const user = await getUserFromRequest(request);
        if (!user) {
            return NextResponse.json(
                { error: 'Unauthorized' },
                { status: 401 }
            );
        }

        const db = (globalThis as any).__CF_DB__ as D1Database | undefined;

        if (!db) {
            // Fallback for local development
            return NextResponse.json({ bookings: [] });
        }

        // Fetch user's bookings from D1 database
        // Try to include carrier_booking_number if column exists
        let bookings;
        try {
            bookings = await db.prepare(
                'SELECT id, container_type, origin, destination, cargo_description, booking_status, carrier_booking_number, created_at FROM bookings WHERE user_id = ? ORDER BY created_at DESC'
            ).bind(user.userId).all<{
                id: string;
                container_type: string;
                origin: string;
                destination: string;
                cargo_description: string;
                booking_status: string;
                carrier_booking_number?: string;
                created_at: number;
            }>();
        } catch (e: any) {
            // Fallback: If carrier_booking_number column doesn't exist, query without it
            if (e?.message?.includes('no such column: carrier_booking_number')) {
                bookings = await db.prepare(
                    'SELECT id, container_type, origin, destination, cargo_description, booking_status, created_at FROM bookings WHERE user_id = ? ORDER BY created_at DESC'
                ).bind(user.userId).all<{
                    id: string;
                    container_type: string;
                    origin: string;
                    destination: string;
                    cargo_description: string;
                    booking_status: string;
                    created_at: number;
                }>();
            } else {
                throw e; // Re-throw if it's a different error
            }
        }

        return NextResponse.json({
            bookings: bookings.results || []
        });
    } catch (error: any) {
        console.error('Fetch bookings error:', error);
        return NextResponse.json(
            { error: 'Failed to fetch bookings', message: error.message },
            { status: 500 }
        );
    }
}
