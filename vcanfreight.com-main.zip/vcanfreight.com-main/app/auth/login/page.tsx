'use client';
import Link from 'next/link';
import React, { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import ThemeToggle from '@/components/ThemeToggle';

export default function LoginPage() {
    const { login, loginWithGoogle, loginAsGuest, isLoading } = useAuth();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        await login(email, password);
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-background-light dark:bg-background-dark p-4 sm:p-6 md:p-8 relative">
            {/* Theme Toggle - Fixed Position */}
            <div className="absolute top-4 right-4 sm:top-6 sm:right-6 z-50">
                <ThemeToggle />
            </div>
            <div className="relative flex w-full flex-col overflow-hidden bg-white dark:bg-background-dark shadow-2xl sm:max-w-[440px] md:max-w-[500px] lg:max-w-[540px] sm:rounded-2xl border border-slate-200 dark:border-slate-800">
                {/* Header Image Section */}
                <div className="relative h-[200px] sm:h-[240px] md:h-[280px] w-full shrink-0">
                    <div
                        className="absolute inset-0 bg-center bg-cover bg-no-repeat"
                        style={{ backgroundImage: 'url("/images/auth-hero.jpg")' }}
                    >
                        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/60 to-white dark:to-background-dark mix-blend-multiply"></div>
                        <div className="absolute inset-0 bg-gradient-to-t from-white dark:from-background-dark via-transparent to-transparent"></div>
                    </div>
                    <div className="absolute top-8 left-0 right-0 flex justify-center">
                        <div className="flex items-center gap-2 bg-white/95 dark:bg-slate-900/90 backdrop-blur-md px-4 py-2 rounded-full shadow-lg ring-1 ring-slate-200/50 dark:ring-slate-700/50">
                            <span className="material-symbols-outlined text-primary text-[22px]">local_shipping</span>
                            <span className="text-xs font-bold tracking-widest text-slate-900 dark:text-white uppercase">VCANFreight</span>
                        </div>
                    </div>
                </div>

                {/* Content Section */}
                <div className="flex flex-1 flex-col px-6 sm:px-8 md:px-10 relative z-10 -mt-10 sm:-mt-12 md:-mt-14">
                    <div className="mb-5 sm:mb-6 md:mb-8 text-center">
                        <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">Welcome Back</h1>
                        <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm md:text-base mt-1 sm:mt-2">Please enter your details to sign in.</p>
                    </div>

                    {/* Toggle Switch */}
                    <div className="flex p-1.5 bg-slate-100 dark:bg-slate-800 rounded-xl mb-8 border border-slate-200 dark:border-slate-700">
                        <button className="flex-1 py-2.5 rounded-lg bg-white dark:bg-slate-600 shadow-sm text-primary dark:text-blue-400 text-sm font-bold transition-all border border-slate-200 dark:border-slate-500">
                            Log In
                        </button>
                        <Link
                            href="/auth/register"
                            className="flex-1 py-2.5 rounded-lg text-slate-500 dark:text-slate-400 text-sm font-medium hover:text-slate-700 dark:hover:text-slate-200 transition-colors text-center flex items-center justify-center"
                        >
                            Register
                        </Link>
                    </div>

                    <form className="flex flex-col gap-5" onSubmit={handleSubmit}>
                        <div className="space-y-1.5">
                            <label className="text-xs font-semibold text-slate-900 dark:text-slate-300 ml-1" htmlFor="email">Email Address</label>
                            <div className="relative group">
                                <input
                                    className="w-full h-[48px] sm:h-[50px] md:h-[52px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 px-10 sm:px-11 md:px-12 text-sm sm:text-base text-slate-900 dark:text-white placeholder:text-slate-400/50 focus:border-primary focus:ring-1 focus:ring-primary focus:bg-white dark:focus:bg-slate-800 outline-none transition-all group-hover:border-slate-300 dark:group-hover:border-slate-600"
                                    id="email"
                                    name="email"
                                    placeholder="name@company.com"
                                    type="email"
                                    autoComplete="username email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                />
                                <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400/60 group-focus-within:text-primary transition-colors text-[20px]">mail</span>
                            </div>
                        </div>

                        <div className="space-y-1.5">
                            <div className="flex justify-between items-center ml-1">
                                <label className="text-xs font-semibold text-slate-900 dark:text-slate-300" htmlFor="password">Password</label>
                                <a className="text-xs font-medium text-primary hover:text-blue-700 transition-colors" href="#">Forgot Password?</a>
                            </div>
                            <div className="relative group">
                                <input
                                    className="w-full h-[48px] sm:h-[50px] md:h-[52px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 px-10 sm:px-11 md:px-12 text-sm sm:text-base text-slate-900 dark:text-white placeholder:text-slate-400/50 focus:border-primary focus:ring-1 focus:ring-primary focus:bg-white dark:focus:bg-slate-800 outline-none transition-all group-hover:border-slate-300 dark:group-hover:border-slate-600"
                                    id="password"
                                    name="password"
                                    placeholder="••••••••"
                                    type="password"
                                    autoComplete="current-password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                />
                                <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400/60 group-focus-within:text-primary transition-colors text-[20px]">lock</span>
                                <button className="absolute right-0 top-0 bottom-0 px-3 text-slate-400/60 hover:text-primary transition-colors flex items-center" type="button">
                                    <span className="material-symbols-outlined text-[20px]">visibility</span>
                                </button>
                            </div>
                        </div>

                        <div className="flex gap-2 sm:gap-3 mt-2">
                            <button
                                className="group flex-1 h-[48px] sm:h-[50px] md:h-[52px] bg-primary hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-600/30 hover:shadow-xl hover:shadow-blue-600/40 active:scale-[0.98] transition-all duration-300 flex items-center justify-center gap-2 text-sm sm:text-base tracking-wide disabled:opacity-50 disabled:cursor-not-allowed"
                                type="submit"
                                disabled={isLoading}
                            >
                                {isLoading ? (
                                    <>
                                        <span className="animate-spin inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full"></span>
                                        <span>Logging in...</span>
                                    </>
                                ) : (
                                    <>
                                        <span>Log In</span>
                                        <span className="material-symbols-outlined text-[18px] group-hover:translate-x-1 transition-transform">arrow_forward</span>
                                    </>
                                )}
                            </button>
                            <button aria-label="Use FaceID" className="h-[50px] w-[50px] shrink-0 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-dark flex items-center justify-center text-slate-400 hover:text-primary hover:border-primary/50 hover:bg-primary/5 transition-all duration-300 shadow-sm hover:shadow-md active:scale-95" type="button">
                                <span className="material-symbols-outlined text-[24px]">face_unlock</span>
                            </button>
                        </div>
                    </form>

                    <div className="relative py-8">
                        <div className="absolute inset-0 flex items-center">
                            <div className="w-full border-t border-slate-200 dark:border-slate-700"></div>
                        </div>
                        <div className="relative flex justify-center">
                            <span className="bg-white dark:bg-background-dark px-3 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Or continue with</span>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-6">
                        <button onClick={async () => await loginWithGoogle()} className="flex h-[46px] items-center justify-center gap-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-dark hover:bg-slate-50 dark:hover:bg-slate-700 transition-all shadow-sm group" type="button">
                            <svg className="h-5 w-5 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"></path>
                                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"></path>
                                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"></path>
                                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"></path>
                            </svg>
                            <span className="text-sm font-semibold text-slate-900 dark:text-white">Google</span>
                        </button>
                        <button className="flex h-[46px] items-center justify-center gap-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-dark hover:bg-slate-50 dark:hover:bg-slate-700 transition-all shadow-sm group" type="button">
                            <svg className="h-5 w-5 dark:fill-white group-hover:scale-110 transition-transform" fill="#000000" viewBox="0 0 24 24">
                                <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24.02-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.74 1.18 0 2.45-1.02 3.8-1.02 1.29.05 2.53.58 3.32 1.34-2.8 1.48-2.35 5.56.54 6.94-1.08 2.81-2.58 4.79-2.74 4.97zM14.63 4.61c-.53 2.56-2.59 4.39-4.82 4.19-.38-2.31 1.58-4.7 4.82-4.19z"></path>
                            </svg>
                            <span className="text-sm font-semibold text-slate-900 dark:text-white">Apple</span>
                        </button>
                    </div>

                    {/* Continue as Guest Button */}
                    <div className="mt-4 mb-6">
                        <button
                            onClick={loginAsGuest}
                            className="w-full h-[46px] border-2 border-slate-300 dark:border-slate-600 bg-transparent hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold rounded-xl transition-all shadow-sm flex items-center justify-center gap-2"
                            type="button"
                        >
                            <span className="material-symbols-outlined text-[20px]">person_off</span>
                            Continue as Guest
                        </button>
                    </div>

                    <div className="mt-auto pb-6 text-center">
                        <p className="text-[11px] leading-relaxed text-slate-500">
                            By logging in, you agree to our <Link href="/terms" className="underline hover:text-primary">Terms of Service</Link> & <Link href="/privacy" className="underline hover:text-primary">Privacy Policy</Link>.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}
