'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { useTranslation } from 'react-i18next';
import RotatingSEOMessages from '@/components/RotatingSEOMessages';
import ThemeToggle from '@/components/ThemeToggle';
import LanguageSelector from '@/components/LanguageSelector';
import MobileHeaderMenu from '@/components/MobileHeaderMenu';

export default function WelcomePage() {
  const router = useRouter();
  const { loginAsGuest } = useAuth();
  const { t } = useTranslation();

  return (
    <div className="relative flex h-full min-h-screen w-full flex-col bg-background-light dark:bg-background-dark group/design-root overflow-x-hidden font-sans text-[#111418] dark:text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 sm:p-6 md:p-8 pb-2">
        {/* Mobile Menu & Language & Theme Toggle */}
        <div className="w-12 sm:w-16 flex items-center justify-start gap-2">
          <div className="md:hidden">
            <MobileHeaderMenu />
          </div>
          <div className="hidden md:flex items-center gap-2">
            <LanguageSelector />
            <ThemeToggle />
          </div>
        </div>
        {/* Logo / Brand Name */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center justify-center rounded-lg bg-primary/10 p-1.5 sm:p-2">
            <span className="material-symbols-outlined text-primary text-2xl sm:text-3xl md:text-4xl">local_shipping</span>
          </div>
          <h2 className="text-lg sm:text-xl md:text-2xl font-bold leading-tight tracking-[-0.015em]">VCANFreight</h2>
        </div>
        {/* Language & Theme Toggle - Mobile */}
        <div className="w-12 sm:w-16 flex items-center justify-end gap-2 md:hidden">
          <LanguageSelector />
          <ThemeToggle />
        </div>
        {/* Spacer for desktop */}
        <div className="hidden md:block w-12 sm:w-16"></div>
      </div>

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col items-center justify-center px-4 sm:px-6 md:px-8 lg:px-12 py-6 sm:py-8 md:py-12 w-full max-w-md sm:max-w-2xl md:max-w-4xl lg:max-w-6xl mx-auto">
        {/* Hero Image */}
        <div className="@container w-full mb-6 sm:mb-8 md:mb-12 animate-scale-in">
          <div className="w-full aspect-[4/3] sm:aspect-[16/9] md:aspect-[21/9] rounded-xl sm:rounded-2xl md:rounded-3xl overflow-hidden shadow-lg sm:shadow-xl md:shadow-2xl dark:shadow-slate-900/50 relative group cursor-pointer">
            <img
              src="/images/welcome-hero.jpg"
              alt="VCANFreight Global Logistics"
              className="absolute inset-0 w-full h-full object-cover"
              loading="eager"
              decoding="async"
              onError={(e) => {
                console.error('Failed to load welcome hero image:', e);
                // Fallback to absolute URL if relative fails
                e.currentTarget.src = 'https://vcanfreight.com/images/welcome-hero.jpg';
              }}
            />
            {/* Overlay for aesthetic tint */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-black/10 to-transparent group-hover:from-black/40 transition-all duration-500 z-10"></div>
            {/* Shine effect on hover */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 z-10"></div>
          </div>
        </div>

        {/* Onboarding Text Content */}
        <div className="flex flex-col items-center text-center space-y-3 sm:space-y-4 md:space-y-6 mb-6 sm:mb-8 md:mb-12">
          <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-extrabold leading-tight tracking-tight text-[#111418] dark:text-white px-4">
            {t('app.tagline')}
          </h1>
          
          {/* Rotating SEO Messages */}
          <div className="w-full max-w-[320px] sm:max-w-md md:max-w-lg lg:max-w-2xl px-4">
            <RotatingSEOMessages />
          </div>
        </div>

        {/* Page Indicators */}
        <div className="flex flex-row items-center justify-center gap-2 sm:gap-3 mb-6 sm:mb-8 md:mb-12">
          <div className="h-2 w-6 sm:h-2.5 sm:w-8 rounded-full bg-primary transition-all duration-300"></div>
          <div className="h-2 w-2 sm:h-2.5 sm:w-2.5 rounded-full bg-[#dbdfe6] dark:bg-slate-700"></div>
          <div className="h-2 w-2 sm:h-2.5 sm:w-2.5 rounded-full bg-[#dbdfe6] dark:bg-slate-700"></div>
        </div>
      </div>

        {/* Bottom Action Buttons */}
      <div className="w-full p-4 sm:p-6 md:p-8 pb-8 sm:pb-12 md:pb-16 bg-background-light dark:bg-background-dark animate-slide-up">
        <div className="flex flex-col sm:flex-row sm:justify-center gap-3 sm:gap-4 max-w-md sm:max-w-2xl md:max-w-4xl mx-auto">
          <Link href="/auth/register" className="group flex w-full sm:w-auto sm:min-w-[200px] md:min-w-[240px] items-center justify-center rounded-xl bg-primary px-5 sm:px-6 md:px-8 py-3 sm:py-4 md:py-5 text-white text-sm sm:text-base md:text-lg font-bold tracking-wide shadow-lg shadow-blue-500/30 hover:shadow-xl hover:shadow-blue-500/40 hover:bg-blue-600 transition-all duration-300 active:scale-[0.98]">
            <span>{t('common.getStarted')}</span>
            <span className="material-symbols-outlined text-[18px] sm:text-[20px] md:text-[22px] ml-2 group-hover:translate-x-1 transition-transform">arrow_forward</span>
          </Link>
          <Link href="/auth/login" className="flex w-full sm:w-auto sm:min-w-[200px] md:min-w-[240px] items-center justify-center rounded-xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 px-5 sm:px-6 md:px-8 py-3 sm:py-4 md:py-5 text-[#111418] dark:text-white text-sm sm:text-base md:text-lg font-bold tracking-wide hover:border-primary hover:bg-primary/5 dark:hover:bg-primary/10 transition-all duration-300 active:scale-[0.98] shadow-sm">
            {t('common.logIn')}
          </Link>
          <button
            onClick={loginAsGuest}
            className="group flex w-full sm:w-auto sm:min-w-[200px] md:min-w-[240px] items-center justify-center gap-2 rounded-xl bg-transparent border-2 border-slate-300 dark:border-slate-600 px-5 sm:px-6 md:px-8 py-3 sm:py-4 md:py-5 text-slate-700 dark:text-slate-300 text-sm sm:text-base md:text-lg font-semibold tracking-wide hover:border-primary hover:bg-primary/5 dark:hover:bg-primary/10 hover:text-primary dark:hover:text-primary transition-all duration-300 active:scale-[0.98]"
          >
            <span className="material-symbols-outlined text-[18px] sm:text-[20px] md:text-[22px]">person_off</span>
            {t('auth.continueAsGuest')}
          </button>
        </div>
        {/* Safe Area Spacer */}
        <div className="h-4 sm:h-6 md:h-8"></div>
      </div>
    </div>
  );
}
